[
  {
    "author": "A. France",
    "quotes": "Lebih baik mengerti sedikit daripada salah mengerti."
  },
  {
    "author": "Abraham Lincoln",
    "quotes": "Hampir semua pria memang mampu bertahan menghadapi kesulitan. Namun, jika Anda ingin menguji karakter sejati pria, beri dia kekuasaan."
  },
  {
    "author": "Aeschylus",
    "quotes": "Bila tekad seseorang kuat dan teguh, Tuhan akan bergabung dalam usahanya."
  },
  {
    "author": "Aesop",
    "quotes": "Penderitaan adalah pelajaran."
  },
  {
    "author": "Albert Einstein",
    "quotes": "Ilmu pengetahuan tanpa agama adalah pincang."
  },
  {
    "author": "Albert Einstein",
    "quotes": "Hidup itu seperti sebuah sepeda, agar tetap seimbang kita harus tetap bergerak."
  },
  {
    "author": "Albert Einstein",
    "quotes": "Perbedaan masa lalu, sekarang, dan masa depan tak lebih dari ilusi yang keras kepala."
  },
  {
    "author": "Albert Einstein",
    "quotes": "Sebuah meja, sebuah kursi, semangkuk buah, dan sebuah biola; apa lagi yang dibutuhkan agar seseorang bisa merasa bahagia?."
  },
  {
    "author": "Albert Enstein",
    "quotes": "Belas kasihanlah terhadap sesama, bersikap keraslah terhadap diri sendiri."
  },
  {
    "author": "Alex Osborn",
    "quotes": "Cara paling baik untuk menggerakkan diri Anda ialah memberi tugas kepada diri sendiri."
  },
  {
    "author": "Alexander A. Bogomoletz",
    "quotes": "Kita tidak boleh kehilangan semangat. Semangat adalah stimulan terkuat untuk mencintai, berkreasi dan berkeinginan untuk hidup lebih lama."
  },
  {
    "author": "Alexander Solzhenitsyn",
    "quotes": "Manusia akan bahagia selama ia memilih untuk bahagia."
  },
  {
    "author": "Ali Javan",
    "quotes": "Saya tidak berharap menjadi segalanya bagi setiap orang. Saya hanya ingin menjadi sesuatu untuk seseorang."
  },
  {
    "author": "Ali bin Abi Thalib",
    "quotes": "Apabila sempurna akal seseorang, maka sedikit perkataannya."
  },
  {
    "author": "Ali bin Abi Thalib",
    "quotes": "Bahagialah orang yang dapat menjadi tuan untuk dirinya, menjadi kusir untuk nafsunya dan menjadi kapten untuk bahtera hidupnya."
  },
  {
    "author": "Ali bin Abi Thalib",
    "quotes": "Sahabat yang jujur lebih besar harganya daripada harta benda yang diwarisi dari nenek moyang."
  },
  {
    "author": "Anne M. Lindbergh",
    "quotes": "Yang palin melelahkan dalam hidup adalah menjadi orang yang tidak tulus."
  },
  {
    "author": "Anonim",
    "quotes": "Terbuka untuk Anda, begitulah Tuhan memberi kita jalan untuk berusaha. Jangan pernah berfikir jalan sudah tertutup."
  },
  {
    "author": "Anonim",
    "quotes": "Penundaan adalah kuburan dimana peluang dikuburkan."
  },
  {
    "author": "Antonie De Saint",
    "quotes": "Cinta bukan saling menatap mata, namun melihat ke arah yang sama bersama-sama."
  },
  {
    "author": "Aristoteles",
    "quotes": "Kita adalah apa yang kita kerjakan berulang kali. Dengan demikian, kecemerlangan bukan tindakan, tetapi kebiasaan."
  },
  {
    "author": "Arnold Glasow",
    "quotes": "Jangan pernah mencoba menjadikan putra atau putri Anda menjadi seperti Anda. Diri Anda hanya cukup satu saja."
  },
  {
    "author": "Art Buchwald",
    "quotes": "Jika Anda bisa membuat orang lain tertawa, maka Anda akan mendapatkan semua cinta yang Anda inginkan."
  },
  {
    "author": "Artemus Ward",
    "quotes": "Masalah akan datang cepat atau lambat. Jika masalah datang, sambut dengan sebaik mungkin. Semakin ramah Anda menyapanya, semakin cepat ia pergi."
  },
  {
    "author": "Ashleigh Brilliant",
    "quotes": "Kita tak bisa melakukan apapun untuk mengubah masa lalu. Tapi apapun yang kita lakukan bisa mengubah masa depan."
  },
  {
    "author": "Augustine",
    "quotes": "Kesabaran adalah teman dari kebijaksanaan."
  },
  {
    "author": "Ayn Rand",
    "quotes": "Orang-orang kreatif termotivasi oleh keinginan untuk maju, bukan oleh keinginan untuk mengalahkan orang lain."
  },
  {
    "author": "B. J. Habibie",
    "quotes": "Dimanapun engkau berada selalulah menjadi yang terbaik dan berikan yang terbaik dari yang bisa kita berikan."
  },
  {
    "author": "Balzac",
    "quotes": "Kebencian seperti halnya cinta, berkobar karena hal-hal kecil."
  },
  {
    "author": "Barbara Sher",
    "quotes": "Anda tidak perlu harus berhasil pada kali pertama."
  },
  {
    "author": "Beecher",
    "quotes": "Satu jam yang intensif, jauh lebih baik dan menguntungkan daripada bertahun-tahun bermimpi dan merenung-renung."
  },
  {
    "author": "Benjamin Disraeli",
    "quotes": "Hal terbaik yang bisa Anda lakukan untuk orang lain bukanlah membagikan kekayaan Anda, tetapi membantu dia untuk memiliki kekayaannya sendiri."
  },
  {
    "author": "Bill Clinton",
    "quotes": "Tidak ada jaminan keberhasilan, tetapi tidak berusaha adalah jaminan kegagalan."
  },
  {
    "author": "Bill Cosby",
    "quotes": "Aku tidak tahu kunci sukses itu apa, tapi kunci menuju kegagalan adalah mencoba membuat semua orang senang."
  },
  {
    "author": "Bill Gates",
    "quotes": "Konsumen yang paling tidak puas adalah sumber berharga untuk belajar."
  },
  {
    "author": "Bill Mccartney",
    "quotes": "Kita ada disini bukan untuk saling bersaing. Kita ada disini untuk saling melengkapi."
  },
  {
    "author": "Brian Koslow",
    "quotes": "Semakin kita bersedia bertanggung jawab atas perbuatan-perbuatan kita, semakin banyak kredibilitas yang kita miliki."
  },
  {
    "author": "Browning",
    "quotes": "Selalu baik untuk memaafkan, tapi yang paling baik adalah melupakan sebuah kesalahan."
  },
  {
    "author": "Bruce Lee",
    "quotes": "Jangan menjadi pohon kaku yang mudah patah. Jadilah bambu yang mampu bertahan melengkung melawan terpaan angin."
  },
  {
    "author": "Budha Gautama",
    "quotes": "Jangan menangis karena kegagalan cinta, sebab manusia akan meninggalkan semua yang dicintainya."
  },
  {
    "author": "Bunda Teresa",
    "quotes": "Jika Anda mengadili orang lain, Anda tak punya waktu untuk mencintai mereka."
  },
  {
    "author": "Bunda Teresa",
    "quotes": "Jika tidak ada perdamaian, hal itu disebabkan kita telah lupa bahwa kita saling membutuhkan."
  },
  {
    "author": "Bung Hatta",
    "quotes": "Kurang cerdas dapat diperbaiki dengan belajar, kurang cekatan dapat diperbaiki dengan pengalaman, kurang jujur sulit memperbaikinya."
  },
  {
    "author": "Burn",
    "quotes": "Banyak orang sukses berkat banyaknya kesulitan dan kesukaran yang mesti dihadapi."
  },
  {
    "author": "Carol Burnet",
    "quotes": "Hanya aku yang bisa merubah hidupku, tak ada seorang pun yang dapat melakukannya untukku."
  },
  {
    "author": "Charles Darwin",
    "quotes": "Yang bisa bertahan hidup bukan spesies yang paling kuat. Bukan juga spesies yang paling cerdas. Tapi spesies yang paling responsif terhadap perubahan."
  },
  {
    "author": "Charles R. Swindoll",
    "quotes": "Hidup adalah 10 persen yang terjadi kepada Anda, 90 persen bagaimana cara Anda menyikapinya."
  },
  {
    "author": "Ching Hai",
    "quotes": "Memperbaiki diri kita adalah memperbaiki dunia."
  },
  {
    "author": "Ching Hai",
    "quotes": "Jangan membeda-bedakan pekerjaan mana yang baik dan mana yang buruk. Masalah muncul jika kita membeda-bedakan dan memihak sesuatu."
  },
  {
    "author": "Ching Hai",
    "quotes": "Kita bekerja harus tanpa pamrih. Itu berlaku untuk segala pekerjaan. Pengabdian tanpa syarat adalah yang terbaik."
  },
  {
    "author": "Ching Hai",
    "quotes": "Kita harus menemukan kekuatan cinta dalam diri kita terlebih dahulu, barulah kita dapat benar-benar mencintai orang lain."
  },
  {
    "author": "Ching Hai",
    "quotes": "Carilah uang secukupnya saja untuk membiayai kehidupan, agar dapat menyisihkan waktu dan tenaga untuk melatih spiritual."
  },
  {
    "author": "Christopher Colombus",
    "quotes": "Harta benda tak membuat seseorang menjadi kaya raya, mereka hanya membuatnya lebih sibuk."
  },
  {
    "author": "Cicero",
    "quotes": "Hati yang penuh syukur, bukan saja merupakan kebajikan terbesar, melainkan induk dari segala kebajikan yang lain."
  },
  {
    "author": "Cicero",
    "quotes": "Hati yang penuh syukur, bukan saja merupakan kebajikan terbesar, melainkan juga induk dari segala kebajikan yang lain."
  },
  {
    "author": "Clarence Darrow",
    "quotes": "Kebebasan itu berasal dari manusia, tidak dari undang-undang atau institusi."
  },
  {
    "author": "Confucius",
    "quotes": "Hidup ini benar-benar sederhana, tapi kita malah bersikeras membuatnya menjadi rumit."
  },
  {
    "author": "Confucius",
    "quotes": "Kemana pun Anda pergi, pergilah dengan sepenuh hati."
  },
  {
    "author": "Confucius",
    "quotes": "Orang yang melakukan kesalahan dan tidak memperbaiki kesalahannya, melalakukan kesalahan yang lainnya."
  },
  {
    "author": "Confucius",
    "quotes": "Kebanggaan kita yang terbesar bukan karena tidak pernah gagal, tetapi bangkit kembali setiap kita jatuh."
  },
  {
    "author": "Cowper",
    "quotes": "Bunga yang tidak akan pernah layu dibumi adalah kebajikan."
  },
  {
    "author": "Cynthia Ozick",
    "quotes": "Untuk membayangkan hal yang tak dapat dibayangkan, dibutuhkan imajinasi yang luar biasa."
  },
  {
    "author": "D. J. Schwartz",
    "quotes": "Kesulitan apapun tidak tahan terhadap keuletan dan ketekunan. Tanpa keuletan, orang yang paling pintar dan paling berbakat sering gagal dalam hidupnya."
  },
  {
    "author": "Dale Carnegie",
    "quotes": "Satu-satunya cara agar kita memperoleh kasih sayang, adalah jangan menuntut agar kita dicintai, tetapi mulailah memberi kasih sayang kepada orang lain tanpa mengharapkan balasan."
  },
  {
    "author": "Dale Carnegie",
    "quotes": "Bila orang yang kuatir akan kekurangannya mau mensyukuri kekayaan yang mereka miliki, mereka akan berhenti kuatir."
  },
  {
    "author": "Dale Carnegie",
    "quotes": "Usahakan membentuk suatu hubungan \"kawat\" antara otak dan hati Anda."
  },
  {
    "author": "Dale Carnegie",
    "quotes": "Senyuman akan membuat kaya jiwa seseorang yang menerimanya, tanpa membuat miskin seseorang yang memberikannya."
  },
  {
    "author": "Dale Carnegie",
    "quotes": "Orang jarang sukses kecuali jika mereka senang dengan apa yang dikerjakannya."
  },
  {
    "author": "David Livingston",
    "quotes": "Saya akan pergi kemanapun selama itu arahnya ke depan."
  },
  {
    "author": "David V. Ambrose",
    "quotes": "Jika Anda punya kemauan untuk menang, Anda sudah mencapai separuh sukses. Jika Anda tidak punya kemauan untuk menang, Anda sudah mencapai separuh kegagalan."
  },
  {
    "author": "David Weinbaum",
    "quotes": "Rahasia menuju hidup kaya adalah mempunyai lebih banyak awal ketimbang akhir."
  },
  {
    "author": "Desbarolles",
    "quotes": "Kebenaran yang tidak dimengerti akan menjadi kesalahan."
  },
  {
    "author": "Descrates",
    "quotes": "Saya berpikir, karena itu saya ada."
  },
  {
    "author": "Djamaludin Abassy",
    "quotes": "Mental yang lemah lebih parah dari fisik yang lemah."
  },
  {
    "author": "Donald Kendall",
    "quotes": "Satu-satunya sukses yang diraih sebelum bekerja hanyalah ada di kamus saja."
  },
  {
    "author": "Dr. Frank Crane",
    "quotes": "Sahabat terbaik dan musuh terburuk kita adalah pikiran-pikiran kita. Pikiran dapat lebih baik dari seorang dokter atau seorang bankir atau seorang teman kepercayaan. Juga dapat lebih berbahaya dadi penjahat."
  },
  {
    "author": "Dr. Ronald Niednagel",
    "quotes": "Pergilah sejauh Anda bisa memandang, dan ketika Anda tiba disana, Anda akan memandang lebih jauh."
  },
  {
    "author": "Dr.\u00a0Johnnetta Cole",
    "quotes": "Jika kamu ingin pergi cepat, pergilah sendiri. Jika kamu ingin pergi jauh, pergilah bersama-sama."
  },
  {
    "author": "Dwigt D. Esenhower",
    "quotes": "Seorang intelektual tidak akan pernah mengatakan lebih daripada apa yang diketahuinya."
  },
  {
    "author": "Earl Campbell",
    "quotes": "Persoalan-persoalan adalah harga yang Anda bayar untuk kemajuan."
  },
  {
    "author": "Earl Campbell",
    "quotes": "Persoalan-persoalan adalah harga yang harus Anda bayar untuk kemajuan."
  },
  {
    "author": "Edgar Alnsel",
    "quotes": "Hidup manusia penuh dengan bahaya, tetapi disitulah letak daya tariknya."
  },
  {
    "author": "Edmund Burke",
    "quotes": "Anda tidak dapat merencanakan masa yang akan datang berdasarkan masa lalu."
  },
  {
    "author": "Edward L. Curtis",
    "quotes": "Optimisme yang tidak disertai dengan usaha hanya merupakan pemikiran semata yang tidak menghasilkan buah."
  },
  {
    "author": "Edward de Bono",
    "quotes": "Jika Anda termasuk orang yang senang menunggu datangnya peluang, Anda adalah bagian dari manusia pada umumnya."
  },
  {
    "author": "Edy Murphy",
    "quotes": "Aku menghabiskan usia 30-an untuk memperbaiki segala kesalahanku di usia 20-an."
  },
  {
    "author": "Einstein",
    "quotes": "Berusaha untuk tidak menjadi manusia yang berhasil tapi berusahalah menjadi manusia yang berguna."
  },
  {
    "author": "Eisenhower",
    "quotes": "Mulai sekarang kita tidak usah membuang-buang waktu barang semenit pun untuk memikirkan orang-orang yang tidak kita sukai."
  },
  {
    "author": "Elanor Roosevelt",
    "quotes": "Ketika kita berhenti membuat kontribusi, kita mulai mati."
  },
  {
    "author": "Elbert Hubbad",
    "quotes": "Kesalahan terbesar yang dibuat manusia dalam kehidupannya adalah terus-menerus merasa takut bahwa mereka akan melakukan kesalahan."
  },
  {
    "author": "Elizabeth Browning",
    "quotes": "Janganlah menyebut orang tidak bahagia sebelum dia mati. Jangan menilai pekerjaan seseorang sebelum pekerjaannya berakhir."
  },
  {
    "author": "Emerson",
    "quotes": "Percaya pada diri sendiri adalah rahasia utama mencapai sukses."
  },
  {
    "author": "Engelbert Huperdinck",
    "quotes": "Anda harus waspada dengan kesenangan. Pastikan bahwa Anda menikmatinya dan bukan dikendalikannya."
  },
  {
    "author": "Erich Watson",
    "quotes": "Kehilangan kekayaan masih dapat dicari kembali, kehilangan kepercayaan sulit didapatkan kembali."
  },
  {
    "author": "Francois De La Roche",
    "quotes": "Bila tidak mampu menemukan kedamaian dalam diri sendiri, tak ada gunanya mencari di tempat lain."
  },
  {
    "author": "Francois De La Roche",
    "quotes": "Kita terbiasa menyembunyikan diri dari orang lain, sampai akhirnya kita sendiri tersembunyi dari diri kita."
  },
  {
    "author": "Francois Roche",
    "quotes": "Kita lebih sibuk menyakinkan orang lain bahwa kita bahagia ketimbang benar-benar merasakan bahagia itu sendiri."
  },
  {
    "author": "Frank Crane",
    "quotes": "Anda mungkin ditipu jika terlalu mempercayai, tetapi hidup Anda akan tersiksa jika tidak cukup mempercayai."
  },
  {
    "author": "Frank Giblin",
    "quotes": "Jadilah diri Anda sendiri. Siapa lagi yang bisa melakukannya lebih baik ketimbang diri Anda sendiri?."
  },
  {
    "author": "Franklin",
    "quotes": "Bila Anda ingin dicintai, cintailah dan bersikaplah sebagai orang yang patut dicintai."
  },
  {
    "author": "Fuller",
    "quotes": "Contoh yang baik adalah nasihat terbaik."
  },
  {
    "author": "Galileo Galilei",
    "quotes": "Rumput yang paling kuat tumbuhnya terdapat di atas tanah yang paling keras."
  },
  {
    "author": "Galileo Galilei",
    "quotes": "Kamu tidak dapat mengajari seseorang apa pun, kamu hanya bisa membantunyanya menemukan apa yang ada dalam dirinya sendiri."
  },
  {
    "author": "Gandhi",
    "quotes": "Mereka yang berjiwa lemah tak akan mampu memberi seuntai maaf tulus. Pemaaf sejati hanya melekat bagi mereka yang berjiwa tangguh."
  },
  {
    "author": "Gandhi",
    "quotes": "Kebahagiaan tergantung pada apa yang dapat Anda berikan, bukan pada apa yang Anda peroleh."
  },
  {
    "author": "Gen Collin Powel",
    "quotes": "Tak ada rahasia untuk menggapai sukses. Sukses itu dapat terjadi karena persiapan, kerja keras dan mau belajar dari kegagalan."
  },
  {
    "author": "George B. Shaw",
    "quotes": "Hidup bukanlah tentang menemukan dirimu sendiri. Hidup adalah tentang menciptakan dirimu sendiri."
  },
  {
    "author": "George III",
    "quotes": "Saya lebih baik kehilangan mahkota daripada melakukan tindakan yang menurut saya memalukan."
  },
  {
    "author": "George Santayana",
    "quotes": "Tidak ada obat untuk kelahiran dan kematian, kecuali menikmati yang ada di antara keduanya."
  },
  {
    "author": "George W.",
    "quotes": "Harapan tak pernah meninggalkan kita, kita yang meninggalkan harapan."
  },
  {
    "author": "Gilbert Chesterton",
    "quotes": "Agar bisa menjadi cukup cerdas untuk meraih semua uang yang diinginkan, kita harus cukup bodoh untuk menginginkannya."
  },
  {
    "author": "Gothe",
    "quotes": "Semua pengetahuan yang kumiliki bisa orang lain peroleh, tapi hatiku hanyalah untuk diriku sendiri."
  },
  {
    "author": "H. N. Spieghel",
    "quotes": "Betapapun tingginya burung terbang, toh dia harus mencari dan mendapatkan makanannya di bumi juga."
  },
  {
    "author": "H.L Hunt",
    "quotes": "Tetapkan apa yang Anda inginkan. Putuskan Anda ingin menukarnya dengan apa. Tentukan prioritas dan laksanakan."
  },
  {
    "author": "Hal Borland",
    "quotes": "Melihat pohon, saya jadi mengerti tentang kesabaran. Memandang rumput, saya jadi menghargai ketekunan."
  },
  {
    "author": "Hamka",
    "quotes": "Kecantikan yang abadi terletak pada keelokan adab dan ketinggian ilmu seseorang, bukan terletak pada wajah dan pakaiannya."
  },
  {
    "author": "Hamka",
    "quotes": "Kita harus yakin bahwa apa yang ditentukan oleh Tuhan untuk kita, itulah yang terbaik."
  },
  {
    "author": "Hamka",
    "quotes": "Berani menegakkan keadilan, walaupun mengenai diri sendiri, adalah puncak segala keberanian."
  },
  {
    "author": "Hamka",
    "quotes": "Hawa nafsu membawa kesesatan dan tidak berpedoman. Sementara akal menjadi pedoman menuju keutamaan. Hawa nafsu menyuruhmu berangan-angan, tetapi akal menyuruhmu menimbang."
  },
  {
    "author": "Harriet Braiker",
    "quotes": "Berusaha berhasil untuk memotivasi dirimu, tapi berusaha untuk selalu sempurna akan membuat tertekan."
  },
  {
    "author": "Helen Keller",
    "quotes": "Kita tidak akan belajar berani dan sabar jika di dunia ini hanya ada kegembiraan."
  },
  {
    "author": "Henri Ford",
    "quotes": "Kegagalan hanyalah kesempatan untuk memulai lagi dengan lebih pandai."
  },
  {
    "author": "Henry David Thoreau",
    "quotes": "Kebaikan adalah satu-satunya investasi yang tidak akan merugikan."
  },
  {
    "author": "Henry Ford",
    "quotes": "Idealis adalah orang yang membantu orang lain untuk makmur."
  },
  {
    "author": "Henry Ford",
    "quotes": "Berpikir itu adalah pekerjaan yang berat di antara segala jenis pekerjaan. Itulah sebabnya sedikit sekali orang yang senang melakukannya."
  },
  {
    "author": "Henry Ford",
    "quotes": "Persaingan yang tujuannya hanya untuk bersaing, untuk mengalahkan orang lain, tak pernah mendatangkan banyak manfaat."
  },
  {
    "author": "Henry Longfellow",
    "quotes": "Kehidupan orang-orang besar mengingatkan kita bahwa kita bisa membuat kehidupan kita luhur."
  },
  {
    "author": "Henry Thoreau",
    "quotes": "Hidupku menjadi hiburanku dan tak hentinya memberikan kejutan. Hidupku bagaikan drama dengan begitu banyak babak tanpa adegan penutup."
  },
  {
    "author": "Hubert Humprey",
    "quotes": "Apa yang Anda lihat adalah apa yang Anda capai."
  },
  {
    "author": "Imam Al-Ghazali",
    "quotes": "Kebahagiaan terletak pada kemenangan memerangi hawa nafsu dan menahan keinginan yang berlebih-lebihan."
  },
  {
    "author": "Imam Ghazali",
    "quotes": "Caci maki dari seorang penjahat merupakan kehormatan bagi seorang yang jujur."
  },
  {
    "author": "J.C.F von Schiller",
    "quotes": "Orang yang terlalu banyak merenung akan meraih sedikit."
  },
  {
    "author": "Jack Hyles",
    "quotes": "Jangan gunakan orang-orang untuk membangun pekerjaan besar, gunakan pekerjaan Anda untuk membangun orang-orang besar."
  },
  {
    "author": "Jackson Brown",
    "quotes": "Kesalahaan terbesar yang mungkin Anda buat adalah mempercayai bahwa Anda bekerja untuk orang lain."
  },
  {
    "author": "Jacques Audiberti",
    "quotes": "Kepengecutan yang paling besar adalah ketika kita membuktikan kekuatan kita kepada kelemanan orang lain."
  },
  {
    "author": "James Thurber",
    "quotes": "Jangan lihat masa lalu dengan penyesalan, jangan pula lihat masa depan dengan ketakutan, tapi lihatlah sekitar Anda dengan penuh kesadaran."
  },
  {
    "author": "Janet Erskine",
    "quotes": "Jangan menunggu keadaan yang ideal. Jangan juga menunggu peluang-peluang terbaik. Keduanya tak akan pernah datang."
  },
  {
    "author": "Jeff Goins",
    "quotes": "Kebanyakan orang sukses yang saya kenal bukan orang yang sibuk, mereka orang yang focus."
  },
  {
    "author": "Jerry West",
    "quotes": "Anda tidak dapat melakukan banyak hal di hidup Anda, jika Anda hanya bekerja di hari-hari yang Anda rasakan baik."
  },
  {
    "author": "Jim Rohn",
    "quotes": "Tembok yang kita bangun untuk menghambat kesedihan, juga membuat kita tertutup dari kebahagiaan."
  },
  {
    "author": "Jim Rohn",
    "quotes": "Jika Anda tidak merancang hidup Anda sendiri, kemungkinan Anda akan menjalani rencana orang lain. Apa yang mereka rencanakan untuk Anda? Tidak banyak."
  },
  {
    "author": "Jim Ryan",
    "quotes": "Motivasi adalah sesuatu yang membuat Anda memulai. Kebiasaan adalah sesuatu yang membuat Anda melanjutkan."
  },
  {
    "author": "Jimi Hendrix",
    "quotes": "Ketika kekuatan akan cinta melebihi kecintaan akan kekuasaan, maka dunia pun menemukan kedamaian."
  },
  {
    "author": "Jimmy Dean",
    "quotes": "Aku tak bisa merubah arah angin, tapi aku bisa menyesuaikan layarku untuk tetap bisa mencapai tujuanku."
  },
  {
    "author": "Joan Baez",
    "quotes": "Kita tak bisa memilih bagaimana kita meninggal atau kapan. Kita hanya bisa memutuskan bagaimana kita hidup. Sekarang."
  },
  {
    "author": "John B. Gough",
    "quotes": "Jika Anda ingin sukses, Anda harus menciptakan peluang untuk diri sendiri."
  },
  {
    "author": "John C. Maxwell",
    "quotes": "Bekerja keras sekarang, merasakan hasilnya nanti; bermalas-malasan sekarang, merasakan akibatnya nanti."
  },
  {
    "author": "John C. Maxwell",
    "quotes": "Untuk menangani diri Anda sendiri, gunakan kepala Anda. Untuk menangani orang lain, gunakan hati Anda."
  },
  {
    "author": "John C. Maxwell",
    "quotes": "Bekerja keras sekarang, merasakannya nanti. Bermalas-malas sekarang, merasakan akibatnya nanti."
  },
  {
    "author": "John Craig",
    "quotes": "Tidak peduli seberapa banyak yang dapat Anda lakukan, tidak peduli seberapa menarik hati kepribadian Anda, Anda tidak dapat melangkah jauh jika Anda tidak dapat bekerja bersama orang lain."
  },
  {
    "author": "John D. Rockefeller",
    "quotes": "Orang termiskin adalah orang yang tidak mempunyai apa-apa kecuali uang."
  },
  {
    "author": "John Gardne",
    "quotes": "Jika kita melayani, maka hidup akan lebih berarti."
  },
  {
    "author": "John Gray",
    "quotes": "Sebenarnya semua kesulitan merupakan kesempatan bagi jiwa yang tumbuh."
  },
  {
    "author": "John Manson",
    "quotes": "Anda dilahirkan orisinal, jadi tidak perlu setengah mati meniru orang lain."
  },
  {
    "author": "John Maxwell",
    "quotes": "Seberapa jauh Anda gagal, tidak masalah, tetapi yang penting seberapa sering Anda bangkit kembali."
  },
  {
    "author": "John Q. Adams",
    "quotes": "Jika tindakan-tindakan Anda mengilhami orang lain untuk bermimpi lebih, belajar lebih, bekerja lebih, dan menjadi lebih baik, Anda adalah seorang pemimpin."
  },
  {
    "author": "John Ruskin",
    "quotes": "Saya yakin, ujian pertama bagi orang besar ialah kerendahan hati."
  },
  {
    "author": "John Ruskin",
    "quotes": "Penghargaan tertinggi untuk kerja keras seseorang bukanlah apa yang ia hasilkan, tapi bagaimana ia berkembang karenanya."
  },
  {
    "author": "John Ruskin",
    "quotes": "Penghargaan tertinggi untuk kerja keras seseorang bukanlah apa yang ia hasilkan, tetapi bagaimana ia berkembang karenanya."
  },
  {
    "author": "John Wolfgang",
    "quotes": "Perbuatan-perbuatan salah adalah biasa bagi manusia, tetapi perbuatan pura-pura itulah sebenarnya yang menimbulkan permusuhan dan pengkhianatan."
  },
  {
    "author": "Joseph Addison",
    "quotes": "Rahmat sering datang kepada kita dalam bentuk kesakitan, kehilangan dan kekecewaan; tetapi kalau kita sabar, kita segera akan melihat bentuk aslinya."
  },
  {
    "author": "Julia Roberts",
    "quotes": "Cinta sejati tidak datang kepadamu, tetapi harus datang dari dalam dirimu."
  },
  {
    "author": "Junius",
    "quotes": "Integritas seseorang diukur dengan tingkah lakunya bukan profesinya."
  },
  {
    "author": "Kahlil Gibran",
    "quotes": "Kita berdoa kalau kesusahan dan membutuhkan sesuatu, mestinya kita juga berdoa dalam kegembiraan besar dan saat rezeki melimpah."
  },
  {
    "author": "Kahlil Gibran",
    "quotes": "Untuk memahami hati dan pikiran seseorang, jangan lihat apa yang sudah dia capai, tapi lihat apa yang dia cita-citakan."
  },
  {
    "author": "Keri Russel",
    "quotes": "Kadang kala, justru keputusan kecil yang akan mampu merubah hidup kita selamanya."
  },
  {
    "author": "Knute Rockne",
    "quotes": "Apabila perjalanan menjadi sulit, orang ulet akan berjalan terus."
  },
  {
    "author": "Kong Hu Cu",
    "quotes": "Orang yang berbudi tinggi selalu berpedoman pada keadilan dan selalu berusaha menjalankan kewajiban."
  },
  {
    "author": "Konrad Adenauer",
    "quotes": "Kita semua hidup di bawah langit yang sama, tetapi tidak semua orang punya cakrawala yang sama."
  },
  {
    "author": "Kung Fu-Tze",
    "quotes": "Ia yang bijak akan merasa malu, jika kata-katanya lebih baik daripada tindakannya."
  },
  {
    "author": "Lao Tzu",
    "quotes": "Saat sadar bahwa kau tidak kekurangan suatu apa pun, seisi dunia menjadi milikku."
  },
  {
    "author": "Lao Tzu",
    "quotes": "Saat sadar bahwa kau tidak kekurangan suatu apa pun, seisi dunia menjadi milikmu."
  },
  {
    "author": "Les Brown",
    "quotes": "Terima tanggung jawab untuk diri Anda sendiri. Sadari bahwa hanya Anda sendiri, bukan orang lain, yang bisa membuat Anda pergi ke tempat yang Anda inginkan."
  },
  {
    "author": "Louis Gittner",
    "quotes": "Meski yang kita hadapi adalah jalan buntu, namun cinta akan membangun jalan layang di atasnya."
  },
  {
    "author": "Louis Pasteur",
    "quotes": "Tahukah Anda rahasia sukses saya dalam mencapai tujuan? Cuma keuletan, tak lebih dan tak kurang."
  },
  {
    "author": "Mahatma Gandhi",
    "quotes": "Kepuasan terletak pada usaha, bukan pada hasil. Berusaha dengan keras adalah kemenangan yang hakiki."
  },
  {
    "author": "Marcel Ayme",
    "quotes": "Kerendahan hati merupakan ruang tunggu bagi kesempurnaan."
  },
  {
    "author": "Maria Sharapova",
    "quotes": "Saya belajar banyak dari kekalahan. Dan kekalahan-kekalahan itu, membuat saya semakin tabah."
  },
  {
    "author": "Mark Cuban",
    "quotes": "Buatlah usaha Anda berhasil dengan satu-satunya cara: kerja keras!."
  },
  {
    "author": "Mark Twain",
    "quotes": "Kebaikan adalah bahasa yang dapat didengar si tuli dan bisa dilihat si buta."
  },
  {
    "author": "Marsha Sinetar",
    "quotes": "Lakukan apa yang Anda senangi, uang akan mengikuti."
  },
  {
    "author": "Martin Luther King",
    "quotes": "Tak ada waktu yang tidak tepat untuk melakukan sesuatu yang benar."
  },
  {
    "author": "Mary McCarthy",
    "quotes": "Kendatipun Anda berada di jalur yang tepat, Anda akan tetap terkejar jika hanya duduk-duduk saja disana."
  },
  {
    "author": "Maxim Gorky",
    "quotes": "Kebahagiaan selalu tampak kecil saat berada dalam genggaman. Tapi coba lepaskan dan Anda akan langsung tahu, betapa besar dan berhargannya kebahagiaan."
  },
  {
    "author": "Mery Hemingway",
    "quotes": "Latih diri Anda untuk tidak khawatir. Kekhawatiran tak pernah memperbaiki apa-apa."
  },
  {
    "author": "Michael Drury",
    "quotes": "Kematangan bukanlah suatu keadaan yang dicapai dengan usia. Dia merupakan perkembangan dari cinta, belajar, membaca dan berpikir hingga menghasilkan kemampuan."
  },
  {
    "author": "Michael Pritchard",
    "quotes": "Anda berhenti tertawa bukan karena bertambah tua. Sebaliknya Anda bertambah tua justru karena berhenti tertawa."
  },
  {
    "author": "Miguel de Cervantes",
    "quotes": "Pepatah adalah kalimat singkat berdasarkan pengalaman panjang."
  },
  {
    "author": "Miguel de Unamuno",
    "quotes": "Tidak dicintai orang lain memang menyedihkan, tapi lebih menyedihkan lagi kalau tidak bisa mencintai orang lain."
  },
  {
    "author": "N. H. Casson",
    "quotes": "Kemiskinan jiwa lebih mengerikan daripada kemiskinan jasmani atau materi."
  },
  {
    "author": "Natalie Portman",
    "quotes": "Anda belum bisa dibilang kaya sampai Anda memiliki sesuatu yang tidak dapat dibeli uang."
  },
  {
    "author": "Nelson Mandela",
    "quotes": "Pendidikan adalah senjata paling ampuh dimana kau dapat menggunakannya untuk merubah dunia."
  },
  {
    "author": "Norman Peale",
    "quotes": "Campakanlah jauh-jauh pikiran murung dan kesal itu, lalu bangkitkanlah."
  },
  {
    "author": "Nunse",
    "quotes": "Bukanlah yang kuat, tetapi yang uletlah yang menjadikan mereka manusia yang besar."
  },
  {
    "author": "O. S. Marden",
    "quotes": "Kemajuan adalah hasil dari memusatkan seluruh kekuatan jiwa dan pikiran pada cita-cita yang dituju."
  },
  {
    "author": "Oliver W. Holmes",
    "quotes": "Semakin lama kita hidup, semakin kita menemukan bahwa kita mirip dengan orang lain."
  },
  {
    "author": "Oprah Winfrey",
    "quotes": "Melakukan yang terbaik pada saat ini akan menempatkan Anda ke tempat terbaik pada saat berikutnya."
  },
  {
    "author": "Oscar Wilde",
    "quotes": "Jika seseorang menyatakan kebenaran, dia yakin; cepat atau lambat; akan mendapatkannya."
  },
  {
    "author": "Pablo Picasso",
    "quotes": "Bila semangat Anda menurun, lakukanlah sesuatu. Kalau Anda telah melakukan sesuatu keadaan tidak berubah, lakukanlah sesuatu yang berbeda."
  },
  {
    "author": "Paul Galvin",
    "quotes": "Jangan takut dengan kesalahan. Kebijaksanaan biasanya lahir dari kesalahan."
  },
  {
    "author": "Paul Harvey",
    "quotes": "Saya tidak pernah melihat suatu monumen didirikan bagi orang pesimis."
  },
  {
    "author": "Pepatah Cina",
    "quotes": "Beranilah menyadari kesalahan dan mulai lagi."
  },
  {
    "author": "Pepatah Cina",
    "quotes": "Benar jadi berani."
  },
  {
    "author": "Pepatah Cina",
    "quotes": "Orang yang bertanya, bodoh dalam 5 menit. Dan orang yang tidak bertanya akan tetap bodoh untuk selamanya."
  },
  {
    "author": "Pepatah Cina",
    "quotes": "Bila saya mendengar, saya akan lupa. Setelah melihat saya bisa mengerti. Dan setelah mengerjakan, barulah saya bisa memahami."
  },
  {
    "author": "Pepatah Cina",
    "quotes": "Orang yang tersenyum selalu lebih kuat dari orang yang marah."
  },
  {
    "author": "Pepatah Cina",
    "quotes": "Orang yang memindahkan gunung memulai dengan memindahkan batu-batu kecil."
  },
  {
    "author": "Pepatah Inggris",
    "quotes": "Orang yang mencari masalah akan selalu mendapatkannya."
  },
  {
    "author": "Pepatah Inggriss",
    "quotes": "Keterampilan dan keyakinan merupakan pasukan bersenjata yang tidak dapat dikalahkan."
  },
  {
    "author": "Pepatah Jepang",
    "quotes": "Sebatang anak panah mudah dipatahkan, tetapi tidak demikian dengan sepuluh anak panah yang disatukan."
  },
  {
    "author": "Pepatah Jepang",
    "quotes": "Visi tanpa aksi adalah mimpi di siang bolong. Aksi tanpa visi adalah mimpi buruk."
  },
  {
    "author": "Pepatah Jerman",
    "quotes": "Orang yang tak pernah mencicipi pahit tak akan tahu apa itu manis."
  },
  {
    "author": "Pepatah Latin",
    "quotes": "Dengan belajar Anda bisa mengajar. Dengan mengajar, Anda belajar."
  },
  {
    "author": "Pepatah Persia",
    "quotes": "Saya menangis karena tak punya sepatu, sampai saya melihat orang tak punya kaki."
  },
  {
    "author": "Pepatah Roma",
    "quotes": "Kesengsaraan menghasilkan ketekunan. Ketekunan menghasilkan watak, dan watak menghasilkan harapan."
  },
  {
    "author": "Pepatah Skotlandia",
    "quotes": "Bila kemauan siap, kaki menjadi ringan."
  },
  {
    "author": "Pepatah Spanyol",
    "quotes": "Mengenal diri sendiri adalah awal dari perbaikan diri."
  },
  {
    "author": "Pepatah Tibet",
    "quotes": "Jangan meremehkan raja yang picik, seperti halnya jangan meremehkan sungai yang kecil."
  },
  {
    "author": "Pepatah Tibet",
    "quotes": "Apabila seseorang mengajarkan sesuatu, dia sendiri harus melaksanakan ajaran itu."
  },
  {
    "author": "Peter Sinclair",
    "quotes": "Kehidupan yang hebat adalah kulminasi dari pemikiran-pemikiran hebat disertai dengan tindakan-tindakan hebat."
  },
  {
    "author": "Phyllis Bottome",
    "quotes": "Ada dua cara mengatasi kesulitan, Anda mengubah kesulitan-kesulitan atau Anda mengubah diri sendiri untuk mengatasinya."
  },
  {
    "author": "Plato",
    "quotes": "Orang bijak berbicara karena mereka mempunyai sesuatu untuk dikatakan, orang bodoh berbicara karena mereka ingin mengatakan sesuatu."
  },
  {
    "author": "Plato",
    "quotes": "Orang bijak berbicara karena ia memiliki sesuatu untuk dikatakan. Orang bodoh berbicara karena ia atau dia harus mengatakan sesuatu."
  },
  {
    "author": "Plato",
    "quotes": "Berbuat tidak adil lebih memalukan daripada menderita ketidakadilan."
  },
  {
    "author": "Plato",
    "quotes": "Siapa yang tidak bisa memimpin dirinya sendiri, tidak akan bisa memimpin orang."
  },
  {
    "author": "Plautus",
    "quotes": "Kesabaran adalah obat terbaik untuk semua masalah."
  },
  {
    "author": "Plautus",
    "quotes": "Jauh lebih mudah memulai secara baik daripada mengakhiri secara baik."
  },
  {
    "author": "Pliny The Elder",
    "quotes": "Harapan adalah tiang yang menyangga dunia."
  },
  {
    "author": "R. A. Kartini",
    "quotes": "Kemenangan gemilang tidak diperoleh dari medan pertempuran saja, tetapi sering diperoleh dari hati."
  },
  {
    "author": "R. Browning",
    "quotes": "kita jatuh untuk bangun, berhenti untuk berjalan, dan tidur untuk bangun."
  },
  {
    "author": "R. W. Shephred",
    "quotes": "Kamu harus menghadapi depresi, sama seperti kamu menghadapi seekor harimau."
  },
  {
    "author": "R.H. Grant",
    "quotes": "Jika Anda mempekerjakan orang-orang yang lebih pintar dari Anda, Anda membuktikan Anda lebih pintar dari mereka."
  },
  {
    "author": "Rabbi Schachtel",
    "quotes": "Kebahagiaan bukanlah memiliki apa yang kita inginkan, melainkan menginginkan apa yang kita miliki."
  },
  {
    "author": "Ralph W. Emerson",
    "quotes": "Satu ons aksi jauh lebih berharga daripada satu ton teori."
  },
  {
    "author": "Ralph W. Emerson",
    "quotes": "Seseorang itu sukses besar jika dia sadar, kegagalan-kegagalannya adalah persiapan untuk kemenangan-kemenangannya."
  },
  {
    "author": "Ralph Waldo Emerson",
    "quotes": "Kedamaian tidak terdapat di dunia luar, melainkan terdapat dalam jiwa manusia itu sendiri."
  },
  {
    "author": "Ralph Waldo Emerson",
    "quotes": "Percayalah kepada orang lain, dan mereka akan tulus kepada Anda. Perlakukan mereka seperti orang besar dan mereka akan memperlihatkan dirinya sebagai orang besar."
  },
  {
    "author": "Rene Descartes",
    "quotes": "Tidak cukup hanya punya otak yang baik. Yang penting adalah menggunakannya secara baik."
  },
  {
    "author": "Richard Bach",
    "quotes": "Tanyakan pada diri sendiri rahasia sukses. Dengarkan jawaban Anda, dan lakukan."
  },
  {
    "author": "Richard C. Miller",
    "quotes": "Jika rumput tetangga lebih hijau, bersyukurlah Anda masih bisa berpijak di tanah untuk melihatnya."
  },
  {
    "author": "Robert Collier",
    "quotes": "Kesempatan Anda untuk sukses di setiap kondisi selalu dapat diukur oleh seberapa besar kepercayaan Anda pada diri sendiri."
  },
  {
    "author": "Robert F. Kennedy",
    "quotes": "Kemajuan merupakan kata-kata merdu, tetapi perubahanlah penggerakknya dan perubahan mempunyai banyak musuh."
  },
  {
    "author": "Robert Frost",
    "quotes": "Dua jalan dipisahkan pohon, dan saya mengambil jalan yang jarang ditempuh orang. Dan itulah yang membuat perubahan."
  },
  {
    "author": "Robert Frost",
    "quotes": "Alasan mengapa kecemasan membunuh lebih banyak orang dibanding kerja adalah, lebih banyak orang cemas dibanding bekerja."
  },
  {
    "author": "Robert G. Ingersoll",
    "quotes": "Sedikit orang kaya yang memiliki harta. Kebanyakan harta yang memiliki mereka."
  },
  {
    "author": "Robert Half",
    "quotes": "Ketekunan bisa membuat yang tidak mungkin jadi mungkin, membuat kemungkinan jadi kemungkinan besar, dan kemungkinan besar menjadi pasti."
  },
  {
    "author": "Robert S. Lynd",
    "quotes": "Hanya ikan yang bodoh yang bisa dua kali kena pancing dengan umpan yang sama."
  },
  {
    "author": "Robert Von Hartman",
    "quotes": "Ambisi seperti air laut, semakin banyak orang meminumnya semakin orang menjadi haus."
  },
  {
    "author": "Robinsori",
    "quotes": "Cemas dan ketakutan adalah akibat kebodohan dan keraguan."
  },
  {
    "author": "Romand Rolland",
    "quotes": "Pahlawan adalah seseorang yang melakukan apa yang mampu dia lakukan."
  },
  {
    "author": "Roosevelt",
    "quotes": "Jika Anda ingin menjadi orang besar, janganlah suka beromong besar, kerjakanlah hal-hal yang kecil dahulu."
  },
  {
    "author": "Ross Cooper",
    "quotes": "Satu-satunya cara untuk mengubah hidup kita adalah dengan mengubah pikiran kita."
  },
  {
    "author": "Ruth P. Freedman",
    "quotes": "Perubahan terjadi ketika seseorang menjadi dirinya sendiri, bukan ketika ia mencoba menjadi orang lain."
  },
  {
    "author": "Salanter Lipkin",
    "quotes": "Perbaiki diri Anda, tetapi jangan jatuhkan orang lain."
  },
  {
    "author": "Samuel Smiles",
    "quotes": "Cara tercepat untuk menuntaskan banyak hal adalah dengan menyelesaikannya satu demi satu."
  },
  {
    "author": "Satya Sai Baba",
    "quotes": "Dua hal yang harus dilupakan, kebaikan yang telah kita lakukan kepada orang lain dan kesalahan orang lain kepada kita."
  },
  {
    "author": "Scott Fitzgerald",
    "quotes": "Ingatlah, jika Anda menutup mulut sebenarnya Anda telah melakukan pilihan."
  },
  {
    "author": "Seneca",
    "quotes": "Hati manusia tidak akan pernah tenteram sebelum berdamai dengan diri sendiri."
  },
  {
    "author": "Seneca",
    "quotes": "Hidup berarti berjuang. Hidup nikmat tanpa badai topan adalah laksana laut yang mati."
  },
  {
    "author": "Shackespeare",
    "quotes": "Kesedihan hanya bisa ditanggulangi oleh orang yang mengalaminya sendiri."
  },
  {
    "author": "Shirley Briggs",
    "quotes": "Beranikan diri untuk menjadi dirimu sendiri, karena kita bisa melakukan hal itu lebih baik daripada orang lain."
  },
  {
    "author": "Soe Hok Gie",
    "quotes": "Lebih baik diasingkan daripada menyerah kepada kemunafikan."
  },
  {
    "author": "Soemantri Metodipuro",
    "quotes": "Langkah pertama untuk memilih keyakinan pada diri sendiri adalah mengenal diri kita sendiri."
  },
  {
    "author": "Sophocles",
    "quotes": "Bila seseorang kehilangan segala sumber kebahagiaan, dia tidak lagi hidup, tapi mayat yang bernafas."
  },
  {
    "author": "St. Jerome",
    "quotes": "Baik, lebih baik, terbaik. Jangan pernah berhenti sampai baik menjadi lebih baik, dan lebih baik menjadi terbaik."
  },
  {
    "author": "Stephen R. Covey",
    "quotes": "Motivasi adalah api dari dalam. Jika orang lain mencoba menyalakannya untuk Anda, kemungkinan apinya hanya menyala sebentar."
  },
  {
    "author": "Steve Jobs",
    "quotes": "Saya bangga, baik pada hal yang tidak kami lakukan maupun pada hal yang kami lakukan."
  },
  {
    "author": "Sujiwo Tejo",
    "quotes": "Cinta tak perlu pengorbanan. Pada saat kau merasa berkorban, pada saat itu cintamu mulai pudar."
  },
  {
    "author": "Sydney Harris",
    "quotes": "Ancaman nyata sebenarnya bukan pada saat komputer mulai bisa berpikir seperti manusia, tetapi ketika manusia mulai berpikir seperti komputer."
  },
  {
    "author": "Theodore Rosevelt",
    "quotes": "Lakukan apa yang dapat Anda lakukan dengan apa yang Anda miliki dan tempat Anda berada."
  },
  {
    "author": "Thomas Alva Edison",
    "quotes": "Banyak kegagalan dalam ini dikarenakan orang-orang tidak menyadari betapa dekatnya mereka dengan keberhasilan saat mereka menyerah."
  },
  {
    "author": "Thomas Carlyle",
    "quotes": "Pergilah sejauh mungkin yang bisa Anda lihat dan Anda akan bisa melihat lebih jauh."
  },
  {
    "author": "Thomas Fuller",
    "quotes": "Orang yang tidak bisa memaafkan orang lain sama saja dengan orang yang memutuskan jembatan yang harus dilaluinya, karena semua orang perlu dimaafkan."
  },
  {
    "author": "Thomas Fuller",
    "quotes": "Menyaksikan adalah mempercayai, tapi merasakan adalah kebenaran."
  },
  {
    "author": "Thomas Jefferson",
    "quotes": "Dalam hal prinsip, usahakan kukuh seperti batu karang. Dalam hal selera, coba berenang mengikuti arus."
  },
  {
    "author": "Tung Desem Waringin",
    "quotes": "Setiap badai pasti berlalu dan saya akan tumbuh semakin kuat."
  },
  {
    "author": "Tyler Durden",
    "quotes": "Setelah kehilangan segalanya, barulah kita bebas melakukan apa saja."
  },
  {
    "author": "Umar bin Khattab",
    "quotes": "Raihlah ilmu dan untuk meraih ilmu belajarlah untuk tenang dan sabar."
  },
  {
    "author": "Vicosta Efran",
    "quotes": "Hiduplah seperti lilin yang menerangi orang lain. Jangan hidup seperti duri yang mencucuk diri dan menyakiti orang lain."
  },
  {
    "author": "Victor Hugo",
    "quotes": "Kesedihan adalah buah. Tuhan tak pernah membiarkannya tumbuh dicabang yang terlalu lemah untuk menanggungnya."
  },
  {
    "author": "Victor Hugo",
    "quotes": "Kebahagian tertinggi dalam kehidupan adalah kepastian bahwa Anda dicintai apa adanya, atau lebih tepatnya dicintai walaupun Anda seperti diri Anda adanya."
  },
  {
    "author": "Victor Hugo",
    "quotes": "Masalahnya bukan kurangnya tenaga, tetapi kurangnya daya kemauan."
  },
  {
    "author": "Vince Lambardi",
    "quotes": "Kemenangan bukanlah segala-galanya, tetapi perjuangan untuk menang adalah segala-galanya."
  },
  {
    "author": "Virginia Wolf",
    "quotes": "Jika Anda tak bisa mengatakan hal yang benar dari diri Anda, maka Anda pun tak bisa mengatakan hal yang benar dari orang lain."
  },
  {
    "author": "W. Camden",
    "quotes": "Burung yang terbang pagi akan memperoleh cacing paling banyak."
  },
  {
    "author": "Walt Disney",
    "quotes": "Cara untuk memulai adalah berhenti berbicara dan mulai lakukan sesuatu."
  },
  {
    "author": "Walter Cronkite",
    "quotes": "Sukses akan lebih permanen jika Anda meraihnya tanpa menghancurkan prinsip-prinsip Anda."
  },
  {
    "author": "Warren Buffett",
    "quotes": "Dari dulu saya selalu yakin saya akan kaya. Saya kira saya tak pernah meragukannya, satu menit pun."
  },
  {
    "author": "Whitney Young",
    "quotes": "Lebih baik menyiapkan diri untuk sebuah peluang dan tidak mendapatkannya daripada punya peluang dan tidak menyiapkan diri."
  },
  {
    "author": "William A. W.",
    "quotes": "Satu-satunya yang bisa menghalangi kita adalah keyakinan yang salah dan sikap yang negatif."
  },
  {
    "author": "William Allen White",
    "quotes": "Saya tidak takut pada hari esok karena saya sudah melihat hari kemarin dan saya mencintai hari ini."
  },
  {
    "author": "William Arthur",
    "quotes": "Guru yang biasa-biasa, berbicara. Guru yang bagus, menerangkan. Guru yang hebat, mendemonstrasikan. Guru yang agung, memberi inspirasi."
  },
  {
    "author": "William F. Halsey",
    "quotes": "Semua masalah menjadi lebih kecil jika Anda tidak mengelaknya, tapi menghadapinya."
  },
  {
    "author": "William J. Johnston",
    "quotes": "Perubahan yang paling bermakna dalam hidup adalah perubahan sikap. Sikap yang benar akan menghasilkan tindakan yang benar."
  },
  {
    "author": "William James",
    "quotes": "Jika Anda harus membuat pilihan dan Anda tidak melakukannya, itu saja sudah pilihan."
  },
  {
    "author": "William James",
    "quotes": "Percaya bahwa hidup itu berharga, dan kepercayaan Anda akan membantu menciptakan hidup yang berharga."
  },
  {
    "author": "William Ralph Inge",
    "quotes": "Kuatir sama seperti membayar bunga untuk uang yang mungkin tak pernah Anda pinjam."
  },
  {
    "author": "William Shakespeare",
    "quotes": "Jangan sering menyalakan api kebencian terhadap musuhmu, karena nanti akan membakar dirimu sendiri."
  },
  {
    "author": "William Shakespeare",
    "quotes": "Bila kamu jujur kepada dirimu sendiri, bagai siang pasti berganti malam, kamu takkan pernah berdusta kepada orang lain."
  },
  {
    "author": "William Shakespeare",
    "quotes": "Kutu yang berani adalah kutu yang bisa berani mendapatkan sarapannya pada bibir seekor singa."
  },
  {
    "author": "Winston Churchill",
    "quotes": "Kita menyambung hidup dengan apa yang kita peroleh, tapi kita menghadirkan kehidupkan dengan apa yang kita berikan."
  },
  {
    "author": "Wolfgang von Gothe",
    "quotes": "Pengetahuan tidaklah cukup, kita harus mengamalkannya. Niat tidak cukup, kita harus melakukannya."
  },
  {
    "author": "Zachary Scott",
    "quotes": "Ketika Anda bertambah tua, Anda akan menemukan satu-satunya hal yang Anda sesali adalah hal-hal yang tidak Anda lakukan."
  },
  {
    "author": "Zig Zaglar",
    "quotes": "Batu fondasi untuk sukses yang seimbang adalah kejujuran, watak, integritas, iman, cinta dan kesetiaan."
  },
  {
    "author": "Zig Zaglar",
    "quotes": "Kebanyakan orang gagal meraih cita-citanya bukan karena mereka tidak mampu, tetapi karena tidak berkomitmen."
  },
  {
    "author": "Zig Zaglar",
    "quotes": "Kita tidak harus hebat saat memulai, tapi kita harus memulai untuk menjadi hebat."
  }
]